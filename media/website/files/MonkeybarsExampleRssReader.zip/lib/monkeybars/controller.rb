require 'thread'

require "monkeybars/inflector"
require "monkeybars/view"
Dir.glob(File.expand_path(File.dirname(__FILE__) + "/handlers/**/*.rb")).each do |file|
  require file
end

module Monkeybars
  # Controllers are the traffic cops of your application.  They decide how to react to
  # events, they coordinate interaction with other controllers and they define some of
  # the overall characteristics of a view such as which events it will generate and how
  # it should respond to things like the close button being pressed.
  # For a general introduction to the idea of MVC and the role of a controller, 
  # please see: http://en.wikipedia.org/wiki/Model-view-controller
  #
  # The controller defines the model and view classes it is associated with.  Most
  # controllers will declare a view and a model that will be instantiated along with
  # the controller and whose life cycle is managed by the controller.  It is not required
  # to declare a view or model but a controller is of questionable usefulness without it.
  #
  # The controller is where you define any events you are interested in handling
  # (see add_listener) as well as one special event, the pressing of the "close" button
  # of the window (see close_action).
  #
  # Example of a controller, this assumes the existance of a Ruby class named MyModel that
  # has an attribute named user_name that is mapped to a field on a subclass of 
  # Monkeybars::View named MyView that has a button named "okButton" and a text field called 
  # userNameTextField:
  #
  #   class MyController < Monkeybars::Controller
  #     set_view :MyView
  #     set_model :MyModel
  # 
  #     add_listener :type => :mouse, :components => ["okButton"]
  #     close_action :exit
  # 
  #     def ok_button_mouse_released(model, event)
  #       puts "The user's name is: #{model.user_name}"
  #     end
  #   end
  #
  # It is important that you do not implement your own initialize and update methods, this
  # will interfere with the operation of the Controller class.
  #
  class Controller
    METHOD_NOT_FOUND = :method_not_found
    @@instance_list = Hash.new {|hash, key| hash[key] = []}
    @@instance_lock = Mutex.new
    
    # Controllers cannot be instantiated via a call to new, instead use instance
    # to retrieve the instance of the view.  Typically views only allow a single
    # instance of a controller but a controller can be declared to allow multiple
    # instances.  When instance is called it will return a new instance until the
    # declared limit has been reached at which point an array of all the controllers
    # will be returned.
    def self.instance
      @@instance_lock.synchronize do
        controller = @@instance_list[self.name]
        if controller.size > 0
          return controller.size == 1 ? controller[0] : controller
        end
        __new__
      end
    end
    
    # Declares the view class (as a symbol) to use when instantiating the controller.
    # 
    #   set_view :MyView
    #
    # The file my_view.rb will be auto-required before attempting to instantiate
    # the MyView class.
    #
    def self.set_view(view)
      require view.underscore
      self.send(:class_variable_set, :@@view, view.constantize)
    end

    # See set_view.  The declared model class is also auto-required prior to the
    # class being instantiated.
    def self.set_model(model)
      require model.underscore
      self.send(:class_variable_set, :@@model, model.constantize)
    end

    # Declares which components you want events to be generated for.  add_listener
    # takes a hash of the form :type => type, :components => [components for events]
    #
    # Current valid types are:
    # * mouse
    # * key
    # * menu
    #
    # New types can be added by implementing the appropriate class in the handlers
    # subdirectory of monkeybars.  See mouse.rb for an example.
    #
    # The array of components should be strings or symbols with the exact naming of the 
    # component in the Java class declared in the view.  As an example, if you have a JFrame 
    # with a text area named infoTextField that you wanted to receive key events for, perhaps
    # to filter certain key input or to enable an auto-completion feature you could use:
    #
    #   add_listener :type => :key, :components => [:infoTextField]
    #
    # To handle the event you would then need to implement a method named
    # <component>_<event> which in this case would be info_text_field_key_pressed,
    # info_text_field_key_released or info_text_field_key_typed.
    #
    # If it is not possible to declare a method, or it is desirable to do so dynamically,
    # you can use the define_handler method.
    def self.add_listener(details)
      klass = "Monkeybars::#{details[:type].camelize}Handler".constantize
      self.send(:include, klass) unless self.ancestors.member? klass
      self.send(:class_variable_get, :@@handlers).push(details)
      hide_protected_class_methods #workaround for JRuby bug #1283
    end
  
    # Declares a method to be called whenever the controller's update method is called.
    def self.update_method(method)
      raise "Argument must be a symbol" unless method.kind_of? Symbol
      raise "'Update' is a reserved method name" if :update == method
      self.send(:class_variable_set, :@@update_method_name, method)
    end
  
    # define_handler takes a component/event name and a block to be called when that
    # event is generated for that component.  This can be used in place of a method
    # declaration for that component/event pair.
    #
    # So, if you have declared:
    #
    #   add_listener :type => :mouse, :components => [:okButton]
    #
    # you could implement the handler using:
    #
    # 
    #   define_handler(:ok_button_mouse_released) do |model, event|
    #     # handle the event here
    #   end
    def self.define_handler(action, &block)
      define_method action, block
    end
    
    # Valid close actions are
    # * :nothing
    # * :dispose (default)
    # * :hide
    # * :exit
    # * :method => symbol_of_method_to_invoke_on_close
    #
    # - close_action :nothing - close action is ignored, this means you cannot
    #   close the window unless you provide another way to do this
    # - close_action :hide - sets the visibility of the window to false
    # - close_action :method => :my_close_method # sets a window listener to
    #   invoke :my_close_method when the windowClosing event is fired    
    # - close_action :exit - closes the application when the window's close
    #   button is pressed    
    # - close_action :dispose - default action, calls Swing's dispose method which
    #   will release the resources for the window and its components, can be 
    #   brought back with a call to show
    def self.close_action(action)
      self.send(:class_variable_set, :@@close_action, action)
    end
    
    def self.inherited(subclass) #:nodoc:
      subclass.send(:class_variable_set, :@@handlers, Array.new)
    end
        
    private 
    def self.hide_protected_class_methods #JRuby bug #1283
      private_class_method :new
    end
    
    hide_protected_class_methods
    
    def self.__new__
      object = new
      @@instance_list[self.name] << object
      object
    end    
    
    def initialize
      @__view = self.class.send(:class_variable_get, "@@view").new if self.class.class_variables.member?("@@view")
      @__model = create_new_model
      handlers = self.class.send(:class_variable_get, :@@handlers)
      unless @__view.nil?
        handlers.each do |handler|            
          add_handler_for handler[:type], handler[:components]
        end
      else
        unless handlers.empty?
          raise "A view must be declared in order to add event listeners"
        end
      end

      if self.class.class_variables.member?("@@update_method_name")
        begin
          self.class.send(:class_variable_set, :@@update_method, method(self.class.send(:class_variable_get, :@@update_method_name)))
        rescue NameError
          raise "Update method: '#{self.class.send(:class_variable_get, :@@update_method_name)}' was not found for class #{self.class}"
        end  
      end
      
      if self.class.class_variables.member?("@@close_action")
        action = self.class.send(:class_variable_get, :@@close_action)
        case action.kind_of?(Hash) ? action.keys[0] : action
        when :nothing
          @__view.close_action(Monkeybars::View::CloseActions::DO_NOTHING)
        when :dispose
          @__view.close_action(Monkeybars::View::CloseActions::DISPOSE)
        when :exit
          @__view.close_action(Monkeybars::View::CloseActions::EXIT)
        when :hide
          @__view.close_action(Monkeybars::View::CloseActions::HIDE)
        when :method
          begin
            close_handler = self.method(action[:method])
          rescue NameError
            raise "Close action method: '#{action[:method]}' was not found for class #{self.class}"
          end
          @__view.close_action(Monkeybars::View::CloseActions::METHOD, MonkeybarsWindowAdapter.new(:windowClosing => close_handler))
        else
          raise "Unkown close action: #{action.kind_of? Hash ? action.keys[0] : action} "
        end
      end

      @closed = false
      load
      
      unless @__view.nil?
        update_view
      end
    end

    public
    def update
      self.class.send(:class_variable_get, :@@update_method).call if self.class.class_variables.member?("@@update_method_name")
    end

    # Triggers updating of the view based on the mapping and the current contents
    # of model
    def update_view
      #begin
      #puts "Text before: #{@__view.articleText.text}"
      #puts "Model's text: #{model.article_text}"
      #rescue Exception; end
      @__view.update_from_model(model)
      #begin
      #puts "Text after #{@__view.articleText.text}"
      #rescue Exception; end
    end
    
    # Returns true if the view is visible, false otherwise
    def visible?
      @__view.visible?
    end

    # Hides the view
    def hide
      @__view.hide
    end

    # Shows the view
    def show
      @__view.show         
    end
    
    # True if close has been called on the controller
    def closed?
      @closed
    end

    # Hides the view and unloads its resources
    def close
      @closed = true          
      unload
      @__view.unload
      @__view.dispose if @__view.respond_to? :dispose
      self.class.send(:class_variable_get, :@@instance_list)[self.class.name].delete self
    end

    # Opens or re-opens the view (if previously closed it also calls load again)
    def open
      if closed?
        load 
        @closed = false
      end
      show
    end

    # Stub to be overriden in sub-class.  This is where you put the code you would
    # normally put in initialize, it will be called whenever a new class is instantiated
    def load; end

    # Stub to be overriden in sub-class.  This is called whenever the controller is closed.
    def unload; end

    # Specific handlers get precedence over general handlers, that is button_mouse_released
    # gets called before mouse_released. A component's name field must be defined in order
    # for the name_event_type style handlers to work.
    def handle_event(event_name, event) #:nodoc:
      method = "#{event.source.name.underscore}_#{event_name}".to_sym
      
      model = create_new_model
      @__view.write_state_to_model(model)
      
      proc = get_method(method)
      
      unless METHOD_NOT_FOUND == proc
        proc.call(model, event)
      else
        method = event_name.to_sym
        
        proc = get_method(method)
        
        unless METHOD_NOT_FOUND == proc
          proc.call(model, event)
        end
      end
    end
    
    private
    def model
      @__model
    end
    
    def create_new_model
      self.class.send(:class_variable_get, "@@model").new if self.class.class_variables.member?("@@model")
    end
    
    def add_handler_for(handler_type, components)
      @__view.add_handler(handler_type, self, components)
    end
    
    def get_method(method)
      begin
        method(method)
      rescue NameError
        METHOD_NOT_FOUND
      end
    end
    
  end
end

# This class is primarily used internally for setting up a handler for window 
# close events although any of the WindowAdapter methods can be set.  To instantiate
# a new MonkeybarsWindowAdapter, pass in a hash of method name symbols and method 
# objects.  The method names must be the various methods from the 
# java.awt.event.WindowListener interface.
#
# For example:
#
#   def handle_window_closing(event)
#     puts "the window is closing"
#   end
#   
#   handler = MonkeybarsWindowAdapter.new(:windowClosing => method(handle_window_closing))
class MonkeybarsWindowAdapter < java.awt.event.WindowAdapter #:nodoc:
  def initialize(methods)
    super()
    raise ArgumentError if methods.size < 1
    methods.each do |key, proc|
      raise ArgumentError unless self.class.method_defined? key
      raise ArgumentError unless proc.respond_to? :to_proc
      self.class.send(:define_method, key, proc.to_proc)
    end
  end
  
  # These methods are implemented here as a workaround for JRuby bug 1327
  def windowActivated(event); end
  def windowClosed(event); end
  def windowClosing(event); end
  def windowDeactivated(event); end
  def windowDeiconified(event); end
  def windowIconified(event); end
  def windowOpened(event); end
end