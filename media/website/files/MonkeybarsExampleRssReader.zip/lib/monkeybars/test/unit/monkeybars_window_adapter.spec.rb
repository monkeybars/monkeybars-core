require 'java'
require 'monkeybars/controller'

describe "MonkeybarsWindowAdapter" do
  def handler_method; end
  
  it "constructor should require argument" do
    lambda {MonkeybarsWindowAdapter.new()}.should raise_error(ArgumentError)
  end
  
  it "only existing methods can be defined" do
    lambda {MonkeybarsWindowAdapter.new(:someMadeUpMethod => nil)}.should raise_error(ArgumentError)
    lambda {MonkeybarsWindowAdapter.new(:windowClosing => method(:handler_method))}.should_not raise_error(ArgumentError)
  end
  
  it "a proc must be provided along with a valid method name" do
    lambda {MonkeybarsWindowAdapter.new(:windowClosing => nil)}.should raise_error(ArgumentError)
    lambda {MonkeybarsWindowAdapter.new(:windowClosing => method(:handler_method))}.should_not raise_error(ArgumentError)
  end
end