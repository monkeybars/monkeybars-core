include_class 'java.awt.event.MouseListener'

module Monkeybars
  module MouseHandler
    include MouseListener

    def mouseClicked(event)
      handle_event("mouse_clicked", event)
    end

    def mouseEntered(event)
      handle_event("mouse_entered", event)
    end

    def mouseExited(event)
      handle_event("mouse_exited", event)
    end

    def mousePressed(event)
      handle_event("mouse_pressed", event)
    end

    def mouseReleased(event)
      handle_event("mouse_released", event)
    end
  end
end