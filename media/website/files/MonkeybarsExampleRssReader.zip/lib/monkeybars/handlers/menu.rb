include_class 'javax.swing.event.MenuListener'

module Monkeybars
  module MenuHandler
    include MenuListener

    def menuCanceled(event)
      handle_event("menu_canceled", event)
    end
    
    def menuDeselected(event)
      handle_event("menu_deselected", event)
    end
    
    def menuSelected(event)
      handle_event("menu_selected", event)
    end
  end
end