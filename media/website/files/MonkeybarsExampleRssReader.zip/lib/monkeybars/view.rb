include_class javax.swing.JComponent
include_class javax.swing.KeyStroke

require "monkeybars/inflector"

module Monkeybars
  # The view is the gatekeeper to the actual Java (or sometimes non-Java) view class.
  # The view defines how data moves into and out of the view via the model.  
  #
  # Any property of the underlying "real" view can be accessed as if it were a
  # property of the view class.
  #
  # Thus if you have a JFrame that has a member variable okButton, you could do
  # the following:
  #
  #   okButton.text = "Confirm"
  #
  # You must use the exact name that is used in the underlying view, no normal
  # JRuby javaName to java_name conversion is performed.  ok_button.text = "Confirm"
  # would fail.
  #
  # Example, (assume a JFrame with a label, text area and button):
  #
  #   class MyView < Monkeybars::View
  #     java_class "com.project.MyCoolJFrame"
  #     map("titleLabel.text").to(:title_text)
  #     map("okButton.text").to(:button_text)
  #     map("mainTextArea.text").to(:text).using(:convert_to_string, :convert_to_array)
  #   
  #     def convert_to_string(model) 
  #       model.text.join("\n")
  #     end
  #   
  #     def convert_to_array(model)
  #       mainTextArea.text.split("\n")
  #     end
  #   end
  #
  # It is important that you do not implement your own initialize method, doing so will
  # interfere with the operation of the View class.
  #
  # It is possible to have a view that is not related to a Java class, in which
  # case no java_class delcaration is used.  If using a pure Ruby view (or
  # manually wrapping a Java class) you must set the @main_view_component
  # member variable yourself.  The object you assign to @main_view_component
  # should respond to any methods that normally interact with the Java object such
  # as visisble?, hide, and dispose
  class View
    # This is an internal class used only by View
    #
    # A ModelMapping records the relationship between the fields of a model and
    # the fields of a view.  Mappings are created for each call to View.map and
    # are cached until the view is instantiated.  The mappings are then inspected
    # for validity and are assigned a type (one of the constants defined in
    # ModelMapping) to speed up processing.  Invalid mappings raise an exception.
    class ModelMapping #:nodoc:
      TYPE_RAW = :raw
      TYPE_PROPERTIES = :both_properties
      TYPE_METHOD = :method
      DIRECTION_IN = :in
      DIRECTION_OUT = :out
      DIRECTION_BOTH = :both
      
      attr_accessor :view_property, :model_property, :in_method, :out_method, :type, :direction
      
      def initialize(view_property = nil, model_property = nil)
	      @view_property = view_property
        @model_property = model_property
        @in_method = nil
        @out_method = nil
      end
      
      def to(model_property)
        @model_property = model_property
        return self
      end

      def using(in_method, out_method)
        @in_method = in_method
        @out_method = out_method
        return self
      end
    end
    
    module CloseActions #:nodoc:
      DO_NOTHING = javax::swing::WindowConstants::DO_NOTHING_ON_CLOSE
      DISPOSE = javax::swing::WindowConstants::DISPOSE_ON_CLOSE
      EXIT = javax::swing::WindowConstants::EXIT_ON_CLOSE
      HIDE = javax::swing::WindowConstants::HIDE_ON_CLOSE
      METHOD = :method
    end
    
    # Declares what class to instantiate when creating the view.  Any listeners
    # set on the controller are added to this class as well as the setting of the
    # close action that is defined in the controller.
    def self.java_class(java_class)
      include_class java_class
      class_name = /.*?\.?(\w+)$/.match(java_class)[1]
      self.send(:class_variable_set, :@@java_class, const_get(class_name))
    end
    
    # Declares a mapping between the controller's model's properties and
    # properties of the view.  This mapping is used when creating the model.
    # If you wish to trigger subsequent updates of the view, you may call 
    # update_from_model manually from the controller.
    #
    # PENDING: There will soon be an option to specify a mapping as recurring
    # at a specified time interval (every 10 seconds, every 100 ms, etc.).
    #
    # There are several ways to declare a mapping based on what level of control
    # you need over the process.  The simplest form is:
    #
    #   map(:foo).to(:bar)
    #
    # Which means, when update_from_model is called, self.foo = model.bar
    #
    # Strings may also be used interchangably with symbols.  If you have nested
    # properties you may specify them as a string:
    #
    #   map("foo.sub_property").to("bar.other_sub_property")
    #
    # which means, self.foo.sub_property = model.bar.other_sub_property
    #
    # It should be noted that these mappings are bi-directional.  They are 
    # referenced for both update_from_model and write_state_to_model.  When used
    # for write_state_to_model the assignment direction is reversed, so a view with
    #
    #   map(:foo).to(:bar)
    #
    # would mean model.bar = self.foo
    # 
    # When a direct assignment is not sufficient you may provide a method to
    # filter or adapt the contents of the model's value before assignment to
    # the view.  This is accomplished by adding a .using call after the .to call.
    # The parameters are the methods to be used when converting from the model 
    # to the view, and when converting from the view back to the model.  Only
    # one method is required (pass nil for the other) but in if a method is not
    # provided, no assignment will be performed when moving in that direction
    # (model to view or vice versa).
    #
    #   map(:foo).to(:bar).using(:from_model, :to_model)
    #
    # would mean self.foo = from_model() when called by update_from_model and
    # model.bar = to_model() when called by write_state_to_model.
    #
    # The final option for mapping properties is a simply your own method.  As with
    # a method provided via the using method you may provide a method for conversion
    # into the view, out of the view or both.
    #
    #   raw_mapping(:from_model, :to_model)
    #
    # would simply invoke the associated method when update_from_model or 
    # write_state_to_model was called.  Thus any assignment to view properties
    # must be done within the method (hence the 'raw').
    def self.map(view_property)
      mappings = self.send(:class_variable_get, :@@view_mappings)
      mapping = ModelMapping.new(view_property)
      mappings << mapping
      return mapping
    end
    
    # See View.map
    def self.raw_mapping(in_method, out_method)
      mappings = self.send(:class_variable_get, :@@view_mappings)
      mapping = ModelMapping.new
      mapping.in_method = in_method
      mapping.out_method = out_method
      mappings << mapping
      nil #prevent accidental raw_mapping().something calls
    end
    
    def self.inherited(subclass) #:nodoc:
      subclass.send(:class_variable_set, :@@view_mappings, Array.new)
    end
    
    def initialize
      @field_references = {}
      @@is_a_java_class = self.class.class_variables.member?("@@java_class") && self.class.send(:class_variable_get, :@@java_class).ancestors.member?(Java::JavaLang::Object)
      if @@is_a_java_class
        @main_view_component = self.class.send(:class_variable_get, :@@java_class).new
        fields = self.class.send(:class_variable_get, :@@java_class).java_class.declared_fields
        fields.each do |declared_field|
          field = get_field(declared_field.name)
          field.name = declared_field.name if field.class.kind_of?(java.awt.Component.class)
        end
        close_action(CloseActions::DISPOSE)
      end
      
      validate_mappings

      load
    end

    # This is set via the constructor, do not call directly unless you know what
    # you are doing.
    #
    # Defines the close action for a visible window.  This method is only applicable
    # for JFrame or decendants, it is ignored for all other classes.
    #
    # close_action expects an action from Monkeybars::View::CloseActions
    #
    # The CloseActions::METHOD action expects a second parameter which should be a
    # MonkeybarsWindowAdapter.
    def close_action(action, handler = nil)
      if ((@main_view_component.class == Java::JavaxSwing::JFrame) || @main_view_component.class.ancestors.member?(Java::JavaxSwing::JFrame))
        if :method == action
          @main_view_component.default_close_operation = CloseActions::DO_NOTHING
          @main_view_component.add_window_listener(handler)
        else
          @main_view_component.set_default_close_operation(action)
        end
      end
    end
    
    def visible?
      return @main_view_component.visible
    end
    
    def visible=(visibility)
      @main_view_component.visible = visibility
    end
    
    def show
      @main_view_component.visible = true
    end
    
    def hide
      @main_view_component.visible = false
    end

    def dispose
      @main_view_component.dispose
    end
    
    # For internal use.
    # This is set via the controller, do not call directly unless you know what
    # you are doing.
    def add_handler(type, handler, components)
      warn "Adding #{type.inspect}"
      components = ["global"] if components.nil?
      components.each do |component|
        if "global" == component
          get_all_components.each do |component|
            component.send("add#{type.to_s.capitalize}Listener".to_sym, handler)
          end
        else
          get_field(component).send("add#{type.to_s.capitalize}Listener", handler)
        end
      end
    end
    
    # Attempts to find a member variable in the underlying @main_view_component
    # object if one is set, otherwise falls back to default method_missing implementation.
    def method_missing(method, *args, &block)
      begin
        return get_field(method)
      rescue NameError
        super
      end
    end
    
    # This method is called when the view is initialized.  It uses the mappings
    # rules declared in the view to copy data from the supplied model into the view.
    def update_from_model(model)
      @valid_mappings.each do |mapping|
        if [View::ModelMapping::DIRECTION_IN, View::ModelMapping::DIRECTION_BOTH].member? mapping.direction
          case mapping.type
          when View::ModelMapping::TYPE_PROPERTIES
            instance_eval("self.#{mapping.view_property.to_s} = model.#{mapping.model_property.to_s}")
          when View::ModelMapping::TYPE_METHOD
            instance_eval("self.#{mapping.view_property.to_s} = method(mapping.in_method).call(model)")
          when View::ModelMapping::TYPE_RAW
            method(mapping.in_method).call(model)
          end
        end
      end
    end
    
    # The inverse of update_from_model.  Called when an event is generated and
    # the controller needs the state of the view.
    def write_state_to_model(model)
      @valid_mappings.each do |mapping|
        if [View::ModelMapping::DIRECTION_OUT, View::ModelMapping::DIRECTION_BOTH].member? mapping.direction
          case mapping.type
          when View::ModelMapping::TYPE_PROPERTIES
            instance_eval("model.#{mapping.model_property.to_s} = self.#{mapping.view_property.to_s}")
          when View::ModelMapping::TYPE_METHOD
            instance_eval("model.#{mapping.model_property.to_s} = method(mapping.out_method).call(model)")
          when View::ModelMapping::TYPE_RAW
            method(mapping.out_method).call(model)
          end
        end
      end
    end
    
    # Stub to be overriden in sub-class.  This is where you put the code you would
    # normally put in initialize, it will be called whenever a new class is instantiated
    def load; end
    
    # Stub to be overriden in sub-class.  This is called whenever the view is closed.
    def unload; end

    private
    # Uses reflection to pull a private field out of the Java objects.  In cases where
    # no Java object is being used, the view object itself is referenced.
    def get_field(field_name)
      field_name = field_name.to_sym
      field = @field_references[field_name]
      if field.nil?
        unless @@is_a_java_class
          field = method(field_name).call
        else
          field_object = nil
          [field_name.to_s, field_name.camelize, field_name.camelize(false)].uniq.each do |name|
            begin
              field_object = self.class.send(:class_variable_get, :@@java_class).java_class.declared_field(name)
            rescue NameError, NoMethodError => e
            end
            break unless field_object.nil?
          end
          raise UndefinedControlError, "There is no control named #{field_name} on view #{@main_view_component.class}" if field_object.nil?
          
          field_object.accessible = true
          field = Java.java_to_ruby(field_object.value(Java.ruby_to_java(@main_view_component)))
        end
        @field_references[field_name] = field
      end
      field
    end
    
    def get_all_components(list = [], components = @main_view_component.components)
      components.each do |component|
        list << component
        get_all_components(list, component.components) if component.respond_to? :components
      end
      list
    end
    
    # TODO: This is ugly complicated code, figure out some way to refactor this
    # into something more readable (maybe helper methods like properties_only? or no_methods?)
    #
    # Raises exceptions for any invalid mapping combinations (nil parameters, mistyped method
    # names, etc.).  Also sets a direction and type for faster processing.
    def validate_mappings  
      @valid_mappings = self.class.send(:class_variable_get, :@@view_mappings).map do |mapping|
        mapping = mapping.dup
        
        if mapping.view_property.nil? and mapping.model_property.nil?
          if mapping.in_method and self.respond_to?(mapping.in_method)
            if mapping.out_method and self.respond_to?(mapping.out_method)
              mapping.direction = View::ModelMapping::DIRECTION_BOTH
            else
              mapping.direction = View::ModelMapping::DIRECTION_IN
            end
          else
            if mapping.out_method and self.respond_to?(mapping.out_method)
              mapping.direction = View::ModelMapping::DIRECTION_OUT
            else
              raise ArgumentError, "Invalid method '#{mapping.in_method}' declared with raw_mapping in #{self.class}" 
            end
          end
          mapping.type = View::ModelMapping::TYPE_RAW
        elsif mapping.in_method.nil? and mapping.out_method.nil?
          raise ArgumentError, "Only one property declared with map in #{self.class}" unless !(mapping.view_property.nil? or mapping.model_property.nil?)
          mapping.direction = View::ModelMapping::DIRECTION_BOTH
          mapping.type = View::ModelMapping::TYPE_PROPERTIES
        else
          raise ArgumentError, "Only one property declared with map in #{self.class}" unless !(mapping.view_property.nil? or mapping.model_property.nil?)
          if mapping.in_method
            raise ArgumentError, "Invalid 'in' method '#{mapping.in_method}' declared with map in #{self.class}" unless self.respond_to? mapping.in_method
            if mapping.out_method
              raise ArgumentError, "Invalid 'out' method '#{mapping.out_method}' declared with map in #{self.class}" unless self.respond_to? mapping.out_method
              mapping.direction = View::ModelMapping::DIRECTION_BOTH
            else
              mapping.direction = View::ModelMapping::DIRECTION_IN
            end
          elsif mapping.out_method
            raise ArgumentError, "Invalid 'out' method '#{mapping.out_method}' declared with map in #{self.class}" unless self.respond_to? mapping.out_method
            mapping.direction = View::ModelMapping::DIRECTION_OUT
          else
            raise ArgumentError, "Invalid mapping declared with map in #{self.class}"
          end
          mapping.type = View::ModelMapping::TYPE_METHOD
        end
        mapping
      end
    end
  end
end

class UndefinedControlError < Exception; end
