include_class 'java.util.Vector'

class RssView < Monkeybars::View
  java_class "RssViewer"
  
  map("feedURL.text").to(:feed_url)
  map("articleText.text").to(:article_text)
  map("articleList.list_data").to(:articles).using(:convert_to_vector, nil)
  map("articleList.selected_index").to(:selected_article_index)
  
  def convert_to_vector(model)
    Vector.new(model.articles)
  end
end