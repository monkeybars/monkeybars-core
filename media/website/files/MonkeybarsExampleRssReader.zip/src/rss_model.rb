class RssModel
  attr_accessor :feed_url, :articles, :article_text, :selected_article_index
  
  def initialize
    #@feed_url = "http://rubyforge.org/export/rss_sfnewreleases.php"
    @feed_url = "http://www.bloglines.com/blog/ThomasEEnebo/rss"
    @articles = []
    @article_text = ""
    @selected_article_index = 0
  end
end