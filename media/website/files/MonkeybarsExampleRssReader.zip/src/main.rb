$: << "lib"
$: << "src"

require 'java'
require 'monkeybars/controller'
require 'monkeybars/view'

require 'rss_controller'

RssController.instance.open