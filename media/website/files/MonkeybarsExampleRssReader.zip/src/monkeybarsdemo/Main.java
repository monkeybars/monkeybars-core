/*
 * Main.java
 * 
 * Created on Sep 19, 2007, 8:28:23 AM
 * 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package monkeybarsdemo;

import java.util.ArrayList;
import org.jruby.Ruby;
import org.jruby.RubyInstanceConfig;

/**
 *
 * @author david
 */
public class Main {

    /** Creates a new instance of Main */
    public Main() {
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        RubyInstanceConfig config = new RubyInstanceConfig();
        Ruby runtime = Ruby.newInstance(config);
        runtime.getLoadService().init(new ArrayList(0));
	runtime.evalScriptlet("require 'src/main.rb'");
    }

}
