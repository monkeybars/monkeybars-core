require 'rss/1.0'
require 'rss/2.0'
require 'open-uri'
require 'cgi'

class RssController < Monkeybars::Controller
  set_view "RssView"
  set_model "RssModel"
  
  close_action :exit
  add_listener :type => :mouse, :components => ["goButton", "articleList"]
  
  def go_button_mouse_released(view_state, event)
    model.feed_url = view_state.feed_url
    content = ""
    Kernel.open(model.feed_url) {|feed| content = feed.read }
    @rss = RSS::Parser.parse(content, false)
    
    model.articles = @rss.items.map {|article| article.title}
    model.article_text = CGI.unescapeHTML(@rss.items[0].description)
    update_view
  end
  
  def article_list_mouse_released(view_state, event)
    if @rss
      model.selected_article_index = view_state.selected_article_index
      model.article_text = CGI.unescapeHTML(@rss.items[model.selected_article_index].description)
      update_view
    end
  end
end