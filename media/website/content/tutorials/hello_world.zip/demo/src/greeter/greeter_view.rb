class GreeterView < ApplicationView
  set_java_class 'greeter.Greeter'

  map :model => :message, :view => "message.text"
end
