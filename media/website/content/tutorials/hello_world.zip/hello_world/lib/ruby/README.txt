3rd party Ruby libs and unpacked gems go here.
