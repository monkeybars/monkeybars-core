class GreetView < ApplicationView
  set_java_class 'greet.Greeter'
  
  map :view => "message.text", :model => :message
end
