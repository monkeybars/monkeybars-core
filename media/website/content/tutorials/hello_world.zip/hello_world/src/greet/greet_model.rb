class GreetModel
  attr_accessor :message
  
  def initialize
    @message = "Swing is ok..."
  end
end
