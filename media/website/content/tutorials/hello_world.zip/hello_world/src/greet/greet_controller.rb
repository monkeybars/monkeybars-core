class GreetController < ApplicationController
  set_model 'GreetModel'
  set_view 'GreetView'
  set_close_action :exit
  
  def improve_button_action_performed
    model.message = "But Swing with Monkeybars is awesome!"
    update_view
  end
end
